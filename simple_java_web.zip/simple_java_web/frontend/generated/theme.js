import {applyTheme as _applyTheme} from './theme-flowcrmtutorial.generated.js';
export const applyTheme = _applyTheme;
